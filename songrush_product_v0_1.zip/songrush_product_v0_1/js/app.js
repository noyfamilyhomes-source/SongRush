const DEFAULT_SONGS = [
  ['Mystify','INXS','Rock'], ['Kryptonite','3 Doors Down','Rock'], ['Everlong','Foo Fighters','Rock'], ['Lay Down Sally','Eric Clapton','Country Rock'],
  ['Wonderwall','Oasis','Pub Classic'], ['Copperhead Road','Steve Earle','Country Rock'], ['Tennessee Whiskey','Chris Stapleton','Country'],
  ['Sweet Caroline','Neil Diamond','Pub Classic'], ['Khe Sanh','Cold Chisel','Australian'], ['Sweet Child O\' Mine','Guns N\' Roses','Rock'],
  ['Patience','Guns N\' Roses','Acoustic'], ['Knockin\' on Heaven\'s Door','Bob Dylan','Classic'], ['Better Be Home Soon','Crowded House','Australian'],
  ['Horses','Daryl Braithwaite','Australian'], ['Eagle Rock','Daddy Cool','Australian'], ['The Gambler','Kenny Rogers','Country'],
  ['Friends in Low Places','Garth Brooks','Country'], ['Save Tonight','Eagle-Eye Cherry','90s'], ['Proud Mary','Tina Turner','Classic'], ['Shallow','Lady Gaga & Bradley Cooper','Pop']
];

const STORAGE_KEY = 'songrush-product-v01';
let state = loadState();
let currentView = 'audience';
let searchTerm = '';

function uid(prefix='id'){ return prefix + '_' + Math.random().toString(36).slice(2,9) + Date.now().toString(36).slice(-4); }
function now(){ return new Date().toISOString(); }

function seedSongs(){
  return DEFAULT_SONGS.map(([title, artist, genre]) => ({ id: uid('song'), title, artist, genre, aliases: [], active: true, stats:{requests:0, raised:0, played:0} }));
}

function loadState(){
  const saved = localStorage.getItem(STORAGE_KEY);
  if(saved){ try { return JSON.parse(saved); } catch(e){} }
  return {
    settings:{ performer:'Andrew Noy', venue:'Tonight\'s Gig', theme:'rock', prices:{standard:2, playAgain:10, playNext:15}, jamzoneShortcut:'SongRush Open Song' },
    songs: seedSongs(),
    queue: [],
    history: [],
    audit: [],
    event:{ id: uid('event'), name:'Friday Night Live', live:true, startedAt: now() },
    payments: []
  };
}
function save(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(state)); }
function audit(action, details={}){ state.audit.unshift({ id:uid('audit'), at:now(), action, details }); state.audit = state.audit.slice(0,80); save(); }
function songById(id){ return state.songs.find(s=>s.id===id); }
function money(n){ return '$' + Number(n||0).toFixed(0); }

function setView(v){ currentView = v; render(); }
function toast(msg){ const t=document.createElement('div'); t.className='toast'; t.textContent=msg; document.body.appendChild(t); setTimeout(()=>t.remove(),2300); }

function requestSong(songId,type='standard'){
  const song = songById(songId); if(!song) return;
  const amount = state.settings.prices[type] ?? state.settings.prices.standard;
  const request = { id:uid('req'), songId, type, amount, status:'waiting', createdAt:now(), customer:'Guest', dedication:'' };
  const payment = { id:uid('pay'), requestId:request.id, amount, status:'authorised', capturedAt:null, type };
  let position = state.queue.length + 1;
  if(type==='playNext') position = 1;
  const item = { id:uid('queue'), requestId:request.id, songId, type, amount, position, status:'waiting', createdAt:now(), request, payment };
  state.payments.push(payment);
  state.queue.push(item);
  reorderQueue();
  song.stats.requests += 1; song.stats.raised += amount;
  audit('REQUEST_ADDED',{song:song.title,type,amount}); save(); render(); toast(`🎉 ${song.title} added to Tonight's Set`);
}

function reorderQueue(){
  const rank = { playing:0, playNext:1, standard:2, playAgain:3 };
  const playing = state.queue.filter(q=>q.status==='playing');
  const waiting = state.queue.filter(q=>q.status==='waiting').sort((a,b)=>(rank[a.type]??9)-(rank[b.type]??9)||new Date(a.createdAt)-new Date(b.createdAt));
  state.queue = [...playing,...waiting].map((q,i)=>({...q,position:i+1}));
}
function startSong(qid){
  state.queue.forEach(q=>{ if(q.status==='playing') q.status='completed'; });
  const q=state.queue.find(x=>x.id===qid) || state.queue.find(x=>x.status==='waiting'); if(!q) return;
  q.status='playing'; q.startedAt=now(); q.payment.status='captured'; q.payment.capturedAt=now(); const song=songById(q.songId); if(song) song.stats.played += 1;
  audit('SONG_STARTED',{song:song?.title, captured:q.amount}); copyForJamzone(song); save(); render(); toast(`▶ ${song?.title} started. Payment captured.`);
}
function finishSong(qid){
  const idx=state.queue.findIndex(q=>q.id===qid); if(idx<0) return; const q=state.queue[idx]; q.status='completed'; q.finishedAt=now(); state.history.unshift(q); state.queue.splice(idx,1); reorderQueue(); audit('SONG_FINISHED',{song:songById(q.songId)?.title}); save(); render(); toast('✔ Song finished');
}
function cancelRequest(qid){
  const idx=state.queue.findIndex(q=>q.id===qid); if(idx<0) return; const q=state.queue[idx]; q.status='cancelled'; q.payment.status='cancelled'; state.history.unshift(q); state.queue.splice(idx,1); reorderQueue(); audit('REQUEST_CANCELLED',{song:songById(q.songId)?.title}); save(); render(); toast('Request cancelled');
}
function moveTop(qid){ const q=state.queue.find(x=>x.id===qid); if(!q)return; q.type='playNext'; audit('QUEUE_MOVED_TOP',{song:songById(q.songId)?.title}); reorderQueue(); save(); render(); }
async function copyForJamzone(song){ if(!song) return; const text = `${song.title} ${song.artist}`; try{ await navigator.clipboard.writeText(text); }catch(e){} }
function openJamzone(songId){ const song=songById(songId); copyForJamzone(song); const sc=encodeURIComponent(state.settings.jamzoneShortcut||'SongRush Open Song'); window.location.href=`shortcuts://run-shortcut?name=${sc}&input=text&text=${encodeURIComponent(song.title+' '+song.artist)}`; toast('Copied for Jamzone'); }

function addSong(e){ e.preventDefault(); const f=new FormData(e.target); const title=(f.get('title')||'').trim(); const artist=(f.get('artist')||'').trim(); if(!title||!artist)return; const dupe=state.songs.find(s=>norm(s.title)===norm(title)&&norm(s.artist)===norm(artist)); if(dupe){ toast('Duplicate song found'); return; } state.songs.unshift({id:uid('song'),title,artist,genre:f.get('genre')||'',aliases:[],active:true,stats:{requests:0,raised:0,played:0}}); audit('SONG_ADDED',{title,artist}); save(); e.target.reset(); render(); }
function deleteSong(id){ const s=songById(id); if(!s)return; s.active=false; audit('SONG_ARCHIVED',{title:s.title}); save(); render(); }
function norm(s){ return String(s||'').toLowerCase().replace(/[^a-z0-9]/g,''); }
function searchSongs(term){
  const t=String(term||'').trim().toLowerCase(); const songs=state.songs.filter(s=>s.active);
  if(!t) return songs.slice(0,20);
  return songs.map(s=>{ const title=s.title.toLowerCase(), artist=s.artist.toLowerCase(), genre=(s.genre||'').toLowerCase(); let score=0; if(title===t)score+=100; if(artist===t)score+=95; if(title.startsWith(t))score+=80; if(artist.startsWith(t))score+=75; if(title.includes(t))score+=55; if(artist.includes(t))score+=50; if(genre.includes(t))score+=20; if(norm(title).includes(norm(t)))score+=35; return {s,score}; }).filter(x=>x.score>0).sort((a,b)=>b.score-a.score).map(x=>x.s).slice(0,30);
}
function applyTheme(){ document.body.className = ''; const t=state.settings.theme; if(t==='country')document.body.classList.add('theme-country'); if(t==='beach')document.body.classList.add('theme-beach'); if(t==='pub')document.body.classList.add('theme-pub'); }

function render(){ applyTheme(); document.getElementById('app').innerHTML = `<div class="app">${topbar()}${view()}${bottomNav()}</div>`; bind(); }
function topbar(){ return `<div class="topbar"><div class="brand"><div class="logo">🎸</div><div><h1>SongRush</h1><p>${state.settings.performer} • ${state.settings.venue}</p></div></div><div class="nav">${['audience','performer','venue','admin'].map(v=>`<button class="tab ${currentView===v?'active':''}" data-view="${v}">${label(v)}</button>`).join('')}</div></div>`; }
function bottomNav(){ return `<div class="bottomnav">${['audience','performer','venue','admin'].map(v=>`<button class="tab ${currentView===v?'active':''}" data-view="${v}">${icon(v)}</button>`).join('')}</div>`; }
function label(v){return {audience:'Audience',performer:'My Gig',venue:'Venue',admin:'Admin'}[v]} function icon(v){return {audience:'🏠',performer:'🎤',venue:'🏨',admin:'⚙️'}[v]}
function view(){ if(currentView==='performer')return performerView(); if(currentView==='venue')return venueView(); if(currentView==='admin')return adminView(); return audienceView(); }
function audienceView(){ const results=searchSongs(searchTerm); return `<section class="hero"><p class="muted">🎤 ${state.settings.performer} LIVE</p><h2>Request your favourite song</h2><p>Find it, request it, watch it move into Tonight's Set.</p><div class="cta"><button class="btn" data-focus-search>🎵 Find My Song</button><button class="btn secondary" data-view="performer">🎤 Tonight's Set</button></div></section><div class="grid"><div class="panel"><h3>🎵 Find My Song</h3><input id="search" class="search" value="${escapeHtml(searchTerm)}" placeholder="Try: Wonderwall, guns, sweet..." autocomplete="off" /><div class="songlist">${results.map(songCard).join('') || `<p class="muted">Can't find it? Ask Andrew or try another spelling.</p>`}</div></div>${queuePanel(false)}</div>`; }
function songCard(s){ return `<article class="song"><div class="song-title">${escapeHtml(s.title)}</div><div class="artist">${escapeHtml(s.artist)} ${s.genre?`• ${escapeHtml(s.genre)}`:''}</div><div class="song-meta"><span class="pill">🔥 ${s.stats.requests} requests</span><span class="pill">${money(s.stats.raised)} behind it</span><span class="pill">▶ ${s.stats.played} played</span></div><div class="actions"><button class="btn green" data-req="${s.id}" data-type="standard">Request ${money(state.settings.prices.standard)}</button><button class="btn gold" data-req="${s.id}" data-type="playNext">Play Next ${money(state.settings.prices.playNext)}</button><button class="btn orange" data-req="${s.id}" data-type="playAgain">Play Again ${money(state.settings.prices.playAgain)}</button></div></article>`; }
function queuePanel(showControls=true){ const playing=state.queue.find(q=>q.status==='playing'); const waiting=state.queue.filter(q=>q.status==='waiting'); return `<aside class="panel"><h3>🎤 Tonight's Set</h3><p class="muted">Now Playing</p><div class="now">${playing ? escapeHtml(songById(playing.songId)?.title) : 'Ready'}</div><br><div class="queue">${waiting.slice(0,8).map((q,i)=>queueItem(q,i,showControls)).join('') || `<p class="muted">No requests yet.</p>`}</div></aside>`; }
function queueItem(q,i,showControls){ const s=songById(q.songId)||{}; return `<div class="queue-item"><div><strong>${i===0?'⭐ NEXT ':''}${escapeHtml(s.title||'Unknown')}</strong><div class="muted">${escapeHtml(s.artist||'')} • ${q.type} • ${money(q.amount)}</div></div>${showControls?`<div class="queue-controls"><button class="btn small" data-start="${q.id}">Start</button><button class="btn secondary small" data-jamzone="${q.songId}">Jamzone</button><button class="btn gold small" data-top="${q.id}">Top</button><button class="btn red small" data-cancel="${q.id}">Cancel</button></div>`:''}</div>`; }
function performerView(){ const playing=state.queue.find(q=>q.status==='playing'); return `<div class="grid"><section class="panel"><h3>🎤 My Gig</h3><p class="muted">Now Playing</p><div class="now">${playing?escapeHtml(songById(playing.songId)?.title):'Nothing playing'}</div><p class="artist">${playing?escapeHtml(songById(playing.songId)?.artist):'Press Start on the next song'}</p><br><div class="cta">${playing?`<button class="btn green" data-finish="${playing.id}">✔ Finish Song</button><button class="btn secondary" data-jamzone="${playing.songId}">🎵 Jamzone</button>`:`<button class="btn" data-start-next>▶ Start Next</button>`}<button class="btn red" data-pause>🚫 Pause Requests</button></div></section>${queuePanel(true)}</div>`; }
function venueView(){ const scans=Number(localStorage.getItem('songrush-scans')||1); const revenue=state.payments.reduce((a,p)=>a+(p.status==='captured'?p.amount:0),0); const authorised=state.payments.reduce((a,p)=>a+(p.status==='authorised'?p.amount:0),0); const completed=state.history.filter(h=>h.status==='completed').length; return `<section class="panel"><h3>🏨 Venue Dashboard</h3><div class="stats"><div class="stat"><p class="muted">QR Scans</p><b>${scans}</b></div><div class="stat"><p class="muted">Requests</p><b>${state.queue.length+state.history.length}</b></div><div class="stat"><p class="muted">Captured</p><b>${money(revenue)}</b></div><div class="stat"><p class="muted">Authorised</p><b>${money(authorised)}</b></div></div><br><div class="grid"><div class="panel"><h3>🔥 Top Songs</h3>${[...state.songs].sort((a,b)=>b.stats.raised-a.stats.raised).slice(0,8).map(s=>`<div class="queue-item"><strong>${escapeHtml(s.title)}</strong><span>${money(s.stats.raised)}</span></div>`).join('')}</div><div class="panel"><h3>🧾 Live Audit</h3>${state.audit.slice(0,10).map(a=>`<div class="queue-item"><div><strong>${a.action}</strong><div class="muted">${new Date(a.at).toLocaleTimeString()}</div></div></div>`).join('')}</div></div></section>`; }
function adminView(){ return `<div class="grid"><section class="panel"><h3>⚙️ Settings</h3><form class="form" id="settingsForm"><input name="performer" value="${escapeAttr(state.settings.performer)}" placeholder="Performer name"><input name="venue" value="${escapeAttr(state.settings.venue)}" placeholder="Venue"><select name="theme"><option value="rock">Rock</option><option value="country">Country</option><option value="beach">Beach</option><option value="pub">Pub</option></select><input name="standard" type="number" value="${state.settings.prices.standard}" placeholder="Request price"><input name="playNext" type="number" value="${state.settings.prices.playNext}" placeholder="Play Next price"><input name="playAgain" type="number" value="${state.settings.prices.playAgain}" placeholder="Play Again price"><input name="jamzoneShortcut" value="${escapeAttr(state.settings.jamzoneShortcut)}" placeholder="Jamzone Shortcut name"><button class="btn">Save Settings</button></form><br><button class="btn secondary" data-export>Export Backup</button><button class="btn red" data-reset>Reset Demo</button></section><section class="panel"><h3>🎵 Add Song</h3><form class="form" id="songForm"><input name="title" placeholder="Song title"><input name="artist" placeholder="Artist"><input name="genre" placeholder="Genre"><button class="btn green">Add Song</button></form><br><h3>Library</h3><div class="queue">${state.songs.filter(s=>s.active).slice(0,50).map(s=>`<div class="queue-item"><div><strong>${escapeHtml(s.title)}</strong><div class="muted">${escapeHtml(s.artist)}</div></div><button class="btn red small" data-del-song="${s.id}">Archive</button></div>`).join('')}</div></section></div>`; }
function bind(){ document.querySelectorAll('[data-view]').forEach(b=>b.onclick=()=>setView(b.dataset.view)); document.querySelectorAll('[data-req]').forEach(b=>b.onclick=()=>requestSong(b.dataset.req,b.dataset.type)); document.querySelectorAll('[data-start]').forEach(b=>b.onclick=()=>startSong(b.dataset.start)); document.querySelectorAll('[data-finish]').forEach(b=>b.onclick=()=>finishSong(b.dataset.finish)); document.querySelectorAll('[data-cancel]').forEach(b=>b.onclick=()=>cancelRequest(b.dataset.cancel)); document.querySelectorAll('[data-top]').forEach(b=>b.onclick=()=>moveTop(b.dataset.top)); document.querySelectorAll('[data-jamzone]').forEach(b=>b.onclick=()=>openJamzone(b.dataset.jamzone)); document.querySelector('[data-start-next]')?.addEventListener('click',()=>startSong()); document.querySelector('[data-focus-search]')?.addEventListener('click',()=>document.getElementById('search')?.focus()); const search=document.getElementById('search'); if(search){ search.oninput=e=>{ searchTerm=e.target.value; render(); setTimeout(()=>document.getElementById('search')?.focus(),0); }; }
  document.getElementById('songForm')?.addEventListener('submit',addSong); document.getElementById('settingsForm')?.addEventListener('submit',e=>{ e.preventDefault(); const f=new FormData(e.target); state.settings.performer=f.get('performer'); state.settings.venue=f.get('venue'); state.settings.theme=f.get('theme'); state.settings.jamzoneShortcut=f.get('jamzoneShortcut'); state.settings.prices={standard:+f.get('standard'),playNext:+f.get('playNext'),playAgain:+f.get('playAgain')}; audit('SETTINGS_SAVED',{}); save(); render(); toast('Settings saved'); }); const sel=document.querySelector('select[name=theme]'); if(sel) sel.value=state.settings.theme; document.querySelectorAll('[data-del-song]').forEach(b=>b.onclick=()=>deleteSong(b.dataset.delSong)); document.querySelector('[data-reset]')?.addEventListener('click',()=>{ if(confirm('Reset SongRush demo data?')){ localStorage.removeItem(STORAGE_KEY); state=loadState(); render(); }}); document.querySelector('[data-export]')?.addEventListener('click',()=>{ const blob=new Blob([JSON.stringify(state,null,2)],{type:'application/json'}); const a=document.createElement('a'); a.href=URL.createObjectURL(blob); a.download='songrush-backup.json'; a.click(); }); document.querySelector('[data-pause]')?.addEventListener('click',()=>toast('Requests paused/resumed demo toggle'));
}
function escapeHtml(s){ return String(s??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c])); }
function escapeAttr(s){ return escapeHtml(s).replace(/`/g,'&#96;'); }
localStorage.setItem('songrush-scans', String(Number(localStorage.getItem('songrush-scans')||0)+1));
render();
