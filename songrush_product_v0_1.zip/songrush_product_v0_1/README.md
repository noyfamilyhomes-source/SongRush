# SongRush Product v0.1

A real runnable static MVP for SongRush.

## How to run
Open `index.html` in Chrome or Safari.

## Included
- Audience screen
- Performer screen
- Venue dashboard
- Admin/settings screen
- Song library
- Search engine
- Queue engine
- Payment simulation: authorise on request, capture when song starts
- Jamzone shortcut launcher
- Theme selector
- LocalStorage persistence
- Export backup

## Jamzone
Create a macOS Shortcut named `SongRush Open Song` that opens Jamzone. SongRush copies the song title + artist to clipboard and attempts to run the shortcut URL.

## Notes
This is local/demo mode. Real Stripe, Firebase, and live sync are the next production step.
